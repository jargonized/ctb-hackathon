

  Welcome to the ca_prng IP-core!
  ===============================

This directory contains the IP-core for a cellular automata based
pattern generator suitable for integration in FPGAs and ASICs.

For documnentation, please check in the doc directory. For changes, see
Changes.txt and for licensing information see the file COPYING.txt

Have fun!


Joachim Strombergson
(c) InformAsic AB 2009
